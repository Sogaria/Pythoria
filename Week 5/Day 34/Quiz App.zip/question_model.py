class Question:
    
    def __init__(self, text: str, answer: bool):
        self.text = text
        self.answer = answer
    

